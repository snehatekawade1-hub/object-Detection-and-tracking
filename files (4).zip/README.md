# Real-Time Object Detection & Tracking

A browser-only project that detects objects in a webcam stream or an uploaded video and gives each object a persistent tracking ID. It uses **HTML, CSS and vanilla JavaScript** with **TensorFlow.js** and the pretrained **COCO-SSD** model. There is no Python, no backend, no API key, and your video never leaves your computer.

## Features

- Webcam input (`getUserMedia`) or local video upload (MP4, WebM and other formats your browser can play)
- Start, Pause, Resume and Stop controls
- Detects the 80 COCO classes (person, car, bicycle, dog, cat, bottle, chair and more)
- Bounding boxes with `#ID class confidence%` labels, one colour per tracking ID
- Custom tracker using IoU, centroid distance and simple motion prediction
- Dashboard: total unique objects, currently tracked, FPS, average confidence, classes in view, live ID list
- Dark theme with blue accents, responsive for laptop, tablet and mobile

## Files

```
object-tracker/
├── index.html   Page structure and CDN script tags
├── style.css    Dark and blue theme, responsive layout
├── script.js    Tracker, model loading, video, drawing, dashboard
└── README.md
```

## Run it with Visual Studio Code

1. Install VS Code from https://code.visualstudio.com/.
2. Open the extensions panel (Ctrl+Shift+X, or Cmd+Shift+X on Mac), search for **Live Server** (by Ritwick Dey) and click Install.
3. Choose **File > Open Folder** and open the `object-tracker` folder.
4. Right-click `index.html` and choose **Open with Live Server** (or click **Go Live** in the bottom-right corner).
5. Your browser opens at `http://127.0.0.1:5500`. Wait until the top-right badge says **Model ready**.

**Why Live Server?** Browsers only allow webcam access on `localhost` or HTTPS pages. Live Server serves the project from `http://127.0.0.1`, which counts as localhost.

**Internet connection:** TensorFlow.js and the COCO-SSD model are downloaded from a CDN when the page opens, so you need to be online at least for the first load. After the first load, many browsers cache the files.

## Use the webcam

1. Make sure the **Webcam** tab is selected.
2. Press **Start** and click **Allow** when the browser asks for camera access.
3. Use **Pause** and **Resume** to freeze and continue, and **Stop** to turn the camera off.

## Process an uploaded video

1. Click the **Video file** tab, then **Choose video**.
2. Select a video from your computer. It appears in the preview panel.
3. Press **Start**. The video plays with live boxes and IDs. Pause and Resume work as usual.
4. When the video ends, the app stops by itself. Press **Start** to run it again.

## How the tracker works

1. Every frame, COCO-SSD returns boxes with a class and confidence.
2. For each existing track, the tracker predicts its new position from its last position and speed.
3. It compares each track with each detection of the same class using IoU (box overlap) and centroid distance.
4. Best matches are paired first. Matched tracks keep their ID.
5. Unmatched detections start a new track. The ID is assigned only after the object is seen in 2 frames, which avoids wasting IDs on one-frame false alarms.
6. Tracks that disappear are kept for 15 frames, so an object that is briefly hidden gets its old ID back. After that the track is removed and IDs are never reused.

You can tune these values in the `ObjectTracker` constructor in `script.js` (`maxMissed`, `minHits`, `minIou`, `maxDistRatio`).

## Dashboard numbers

- **Total objects detected**: number of different objects that have received an ID since you pressed Start
- **Currently tracked**: objects visible in the current frame
- **FPS**: detections processed per second (depends on your computer)
- **Avg. confidence**: mean confidence of the visible objects

## Troubleshooting

**Model fails to load / "Model failed to load"**
- Check your internet connection and press **Retry** (or reload the page).
- Make sure no ad blocker or firewall blocks `cdn.jsdelivr.net`.
- Open the browser console (F12) to see the exact error.
- Use a current version of Chrome, Edge, Firefox or Safari.

**Webcam permission denied**
- Click the camera or lock icon in the address bar, set Camera to Allow, then press Start again.
- On Windows, check Settings > Privacy > Camera. On macOS, check System Settings > Privacy & Security > Camera.
- If the app says another program is using the camera, close Zoom, Teams or other tabs that use it.

**"Webcam access needs HTTPS or localhost"**
- Open the project through Live Server (`http://127.0.0.1:5500`) rather than double-clicking `index.html`.

**Uploaded video will not play**
- Convert it to MP4 (H.264) or WebM. Not every browser supports every format (for example, some .mkv or .avi files).

**Low FPS or a laggy page**
- Close other tabs and apps, and use a browser with hardware acceleration enabled (WebGL).
- Use a lower-resolution video. Detection runs on the full frame, so smaller frames are faster.
- Check the badge: `Model ready (webgl)` is fast, `(cpu)` is slow.

**Boxes are slightly off or the video looks stretched**
- The canvas is sized to the video's real resolution and sits exactly on top of it. Reload the page and start again if you resized the window while a video was loading.

**Browser compatibility**
- Works in current Chrome, Edge, Firefox and Safari on desktop. On phones, webcam access works over HTTPS or localhost only, so open it from a device that serves it securely.
