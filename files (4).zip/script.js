'use strict';

/* =====================================================================
   Real-Time Object Detection & Tracking
   - Detection: TensorFlow.js + pretrained COCO-SSD (loaded once)
   - Tracking : IoU + centroid distance, with a simple motion prediction
   - Video    : webcam (getUserMedia) or an uploaded video file
   - Drawing  : HTML5 canvas laid exactly on top of the <video>
   ===================================================================== */


/* =====================================================================
   1. OBJECT TRACKER  (pure JavaScript, no dependencies)
   ---------------------------------------------------------------------
   Every frame we receive detections: { bbox: [x, y, w, h], class, score }.
   We match them to existing tracks like this:
     1. Predict where each track should be now (last box + its velocity).
     2. For every track/detection pair of the SAME class, compute
          - IoU (overlap of the two boxes)
          - centroid distance (relative to the track's diagonal)
        A pair is a candidate if the boxes overlap enough OR the centres
        are close enough. Lost tracks get a wider search area.
     3. Candidate pairs are sorted by score (60% IoU + 40% closeness)
        and matched greedily, best first.
     4. Unmatched detections start new "tentative" tracks. A track only
        gets a visible ID after it has been seen in `minHits` frames,
        which stops one-frame false alarms from wasting IDs.
     5. Unmatched tracks are kept for `maxMissed` frames, so an object
        that is briefly hidden gets its old ID back when it returns.
   IDs are never reused.
   ===================================================================== */
class ObjectTracker {
  constructor(options = {}) {
    this.maxMissed = options.maxMissed ?? 15;       // frames a confirmed track may be lost
    this.minHits = options.minHits ?? 2;            // frames needed before an ID is assigned
    this.minIou = options.minIou ?? 0.1;            // overlap that alone allows a match
    this.maxDistRatio = options.maxDistRatio ?? 0.5; // allowed centre shift / box diagonal
    this.duplicateIou = options.duplicateIou ?? 0.7; // new detection this similar to a matched box is ignored
    this.reset();
  }

  reset() {
    this.tracks = [];
    this.nextId = 1;
  }

  /** How many different objects have received an ID so far. */
  totalUnique() {
    return this.nextId - 1;
  }

  /** Intersection-over-Union of two [x, y, w, h] boxes (0 = no overlap, 1 = identical). */
  static iou(a, b) {
    const x1 = Math.max(a[0], b[0]);
    const y1 = Math.max(a[1], b[1]);
    const x2 = Math.min(a[0] + a[2], b[0] + b[2]);
    const y2 = Math.min(a[1] + a[3], b[1] + b[3]);
    const inter = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
    const union = a[2] * a[3] + b[2] * b[3] - inter;
    return union > 0 ? inter / union : 0;
  }

  /** Where we expect the track to be in the current frame. */
  static predict(track) {
    const steps = Math.min(track.missed + 1, 8); // do not extrapolate too far
    return [
      track.bbox[0] + track.vx * steps,
      track.bbox[1] + track.vy * steps,
      track.bbox[2],
      track.bbox[3],
    ];
  }

  /**
   * Process one frame of detections.
   * Returns the confirmed tracks that were seen in THIS frame.
   */
  update(detections) {
    const tracks = this.tracks;

    // Step 1: predict
    const predicted = tracks.map((t) => ObjectTracker.predict(t));

    // Step 2: build candidate pairs
    const pairs = [];
    tracks.forEach((t, ti) => {
      detections.forEach((d, di) => {
        if (t.class !== d.class) return; // never match different classes
        const pb = predicted[ti];
        const iou = ObjectTracker.iou(pb, d.bbox);
        const dx = pb[0] + pb[2] / 2 - (d.bbox[0] + d.bbox[2] / 2);
        const dy = pb[1] + pb[3] / 2 - (d.bbox[1] + d.bbox[3] / 2);
        const diag = Math.hypot(t.bbox[2], t.bbox[3]) || 1;
        const distNorm = Math.hypot(dx, dy) / diag;
        const gate = this.maxDistRatio * (1 + 0.1 * t.missed); // wider for lost tracks
        if (iou < this.minIou && distNorm > gate) return;
        const closeness = Math.max(0, 1 - distNorm / gate);
        pairs.push({ ti, di, score: 0.6 * iou + 0.4 * closeness });
      });
    });

    // Step 3: greedy matching, best pairs first
    pairs.sort((a, b) => b.score - a.score);
    const usedTracks = new Set();
    const usedDets = new Set();
    for (const p of pairs) {
      if (usedTracks.has(p.ti) || usedDets.has(p.di)) continue;
      usedTracks.add(p.ti);
      usedDets.add(p.di);
      this._applyMatch(tracks[p.ti], detections[p.di]);
    }

    // Step 4: tracks without a detection are "missed" this frame
    tracks.forEach((t, ti) => {
      if (!usedTracks.has(ti)) t.missed += 1;
    });

    // Step 5: unmatched detections become new tentative tracks
    detections.forEach((d, di) => {
      if (usedDets.has(di)) return;
      // Skip near-copies of a box that was just matched (duplicate detection).
      const isDuplicate = tracks.some(
        (t, ti) => usedTracks.has(ti) && t.class === d.class && ObjectTracker.iou(t.bbox, d.bbox) > this.duplicateIou
      );
      if (isDuplicate) return;
      const track = {
        id: null, class: d.class, bbox: d.bbox.slice(), score: d.score,
        vx: 0, vy: 0, hits: 1, missed: 0, confirmed: false, color: null,
      };
      this._confirmIfReady(track);
      tracks.push(track);
    });

    // Step 6: remove stale tracks
    this.tracks = tracks.filter((t) => (t.confirmed ? t.missed <= this.maxMissed : t.missed === 0));

    return this.tracks.filter((t) => t.confirmed && t.missed === 0);
  }

  _applyMatch(track, det) {
    const [ox, oy, ow, oh] = track.bbox;
    const [nx, ny, nw, nh] = det.bbox;
    const frames = track.missed + 1;

    // Velocity = change of centre per frame, smoothed.
    const dx = (nx + nw / 2 - (ox + ow / 2)) / frames;
    const dy = (ny + nh / 2 - (oy + oh / 2)) / frames;
    track.vx = 0.6 * track.vx + 0.4 * dx;
    track.vy = 0.6 * track.vy + 0.4 * dy;

    // Light smoothing of the box so it does not jitter (skip it after a gap).
    const a = track.missed > 0 ? 1 : 0.7;
    track.bbox = [a * nx + (1 - a) * ox, a * ny + (1 - a) * oy, a * nw + (1 - a) * ow, a * nh + (1 - a) * oh];
    track.score = det.score;
    track.hits += 1;
    track.missed = 0;
    this._confirmIfReady(track);
  }

  _confirmIfReady(track) {
    if (!track.confirmed && track.hits >= this.minHits) {
      track.confirmed = true;
      track.id = this.nextId++;
      // Golden-angle hue spacing gives every ID a clearly different colour.
      track.color = `hsl(${Math.round((track.id * 137.508) % 360)}, 85%, 60%)`;
    }
  }
}


/* =====================================================================
   2. DOM REFERENCES AND APPLICATION STATE
   ===================================================================== */
const $ = (id) => document.getElementById(id);

const el = {
  video: $('video'), canvas: $('overlay'), viewport: $('viewport'), stage: $('stage'),
  placeholder: $('placeholder'), placeholderText: $('placeholderText'),
  modelStatus: $('modelStatus'), modelStatusText: $('modelStatusText'),
  banner: $('banner'), bannerText: $('bannerText'), retryBtn: $('retryBtn'),
  tabWebcam: $('tabWebcam'), tabFile: $('tabFile'),
  fileLabel: $('fileLabel'), fileInput: $('fileInput'), fileName: $('fileName'),
  startBtn: $('startBtn'), stopBtn: $('stopBtn'), pauseBtn: $('pauseBtn'), resumeBtn: $('resumeBtn'),
  stateBadge: $('stateBadge'),
  statTotal: $('statTotal'), statCurrent: $('statCurrent'), statFps: $('statFps'), statConf: $('statConf'),
  confBar: $('confBar'), minConf: $('minConf'), minConfValue: $('minConfValue'),
  classChips: $('classChips'), trackList: $('trackList'),
};

const ctx = el.canvas.getContext('2d');
const tracker = new ObjectTracker();

let model = null;            // COCO-SSD model (loaded once)
let modelReady = false;
let state = 'idle';          // idle | starting | running | paused
let sourceType = 'webcam';   // webcam | file
let stream = null;           // active webcam MediaStream
let fileURL = null;          // object URL of the uploaded video
let fileReady = false;
let rafId = 0;               // requestAnimationFrame handle
let busy = false;            // true while model.detect() is running
let runToken = 0;            // changes on every start/stop so stale results can be ignored
let lastVideoTime = -1;      // used to skip duplicate frames of uploaded videos
let lastFrameTime = 0;
let fps = 0;
let minConfidence = 0.55;


/* =====================================================================
   3. UI HELPERS
   ===================================================================== */
function showBanner(text, type = 'info', withRetry = false) {
  el.bannerText.textContent = text;
  el.banner.className = 'banner ' + type;
  el.banner.hidden = false;
  el.retryBtn.hidden = !withRetry;
}

function hideBanner() {
  el.banner.hidden = true;
}

function setModelStatus(kind, text) {
  el.modelStatus.className = 'pill pill-' + kind; // loading | ready | error
  el.modelStatusText.textContent = text;
}

/** Enable/disable buttons depending on the current state. */
function updateControls() {
  const idle = state === 'idle';
  el.startBtn.disabled = !(idle && modelReady && (sourceType === 'webcam' || fileReady));
  el.stopBtn.disabled = !(state === 'running' || state === 'paused');
  el.pauseBtn.disabled = state !== 'running';
  el.resumeBtn.disabled = state !== 'paused';
  el.tabWebcam.disabled = !idle;
  el.tabFile.disabled = !idle;
  el.fileInput.disabled = !idle;
  el.fileLabel.classList.toggle('disabled', !idle);

  const labels = { idle: 'Idle', starting: 'Starting…', running: 'Running', paused: 'Paused' };
  el.stateBadge.textContent = labels[state];
  el.stateBadge.className = 'state-badge ' + state;

  // Show the placeholder when there is nothing to look at yet.
  const showPlaceholder = state === 'idle' && (sourceType === 'webcam' || !fileReady);
  el.placeholder.hidden = !showPlaceholder;
  el.placeholderText.textContent =
    sourceType === 'webcam' ? 'Press Start to turn on your webcam' : 'Choose a video file, then press Start';
}

function setState(next) {
  state = next;
  updateControls();
}

/** Keep the canvas pixel size equal to the video size and the box at the right aspect ratio. */
function sizeStage() {
  const vw = el.video.videoWidth || 1280;
  const vh = el.video.videoHeight || 720;
  if (el.canvas.width !== vw || el.canvas.height !== vh) {
    el.canvas.width = vw;
    el.canvas.height = vh;
  }
  const maxHeight = Math.max(240, window.innerHeight * 0.66);
  const width = Math.min(el.stage.clientWidth, maxHeight * (vw / vh));
  el.viewport.style.aspectRatio = `${vw} / ${vh}`;
  el.viewport.style.width = `${Math.floor(width)}px`;
}

function clearOverlay() {
  ctx.clearRect(0, 0, el.canvas.width, el.canvas.height);
}


/* =====================================================================
   4. MODEL LOADING (runs once, when the page opens)
   ===================================================================== */
async function loadModel() {
  setModelStatus('loading', 'Loading model…');
  el.retryBtn.hidden = true;
  try {
    if (typeof tf === 'undefined' || typeof cocoSsd === 'undefined') {
      throw new Error('LIBS_MISSING');
    }
    await tf.ready(); // picks the fastest backend (WebGL when available)
    model = await cocoSsd.load({ base: 'lite_mobilenet_v2' }); // small and fast
    try {
      // Warm-up: the first prediction is slow, so do it now on a blank canvas.
      const warm = document.createElement('canvas');
      warm.width = warm.height = 64;
      await model.detect(warm);
    } catch (e) { /* warm-up is optional */ }

    modelReady = true;
    setModelStatus('ready', `Model ready (${tf.getBackend()})`);
    updateControls();
  } catch (err) {
    modelReady = false;
    setModelStatus('error', 'Model failed to load');
    const msg = err.message === 'LIBS_MISSING'
      ? 'TensorFlow.js could not be downloaded. Check your internet connection (the libraries load from a CDN), then reload the page.'
      : 'The COCO-SSD model could not be loaded. Check your internet connection and try again. Details: ' + err.message;
    showBanner(msg, 'error', true);
    updateControls();
  }
}


/* =====================================================================
   5. VIDEO SOURCES
   ===================================================================== */
function waitForMetadata() {
  return new Promise((resolve, reject) => {
    const v = el.video;
    if (v.readyState >= 1 && v.videoWidth) return resolve();
    const done = () => { cleanup(); resolve(); };
    const fail = () => { cleanup(); reject(new Error('VIDEO_LOAD_FAILED')); };
    const timer = setTimeout(() => { cleanup(); reject(new Error('VIDEO_TIMEOUT')); }, 15000);
    function cleanup() {
      clearTimeout(timer);
      v.removeEventListener('loadedmetadata', done);
      v.removeEventListener('error', fail);
    }
    v.addEventListener('loadedmetadata', done);
    v.addEventListener('error', fail);
  });
}

async function startWebcam() {
  if (!window.isSecureContext) {
    const e = new Error('insecure'); e.name = 'InsecureContextError'; throw e;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    const e = new Error('unsupported'); e.name = 'NotSupportedError'; throw e;
  }
  stream = await navigator.mediaDevices.getUserMedia({
    video: { width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false,
  });
  // If the camera is unplugged or taken away, stop cleanly.
  stream.getVideoTracks()[0].addEventListener('ended', () => {
    if (state === 'running' || state === 'paused') {
      stopAll();
      showBanner('The camera was disconnected.', 'error');
    }
  });
  el.video.pause();
  el.video.removeAttribute('src');
  el.video.srcObject = stream;
  await waitForMetadata();
  await el.video.play();
}

async function startFile() {
  if (!fileURL) throw new Error('NO_FILE');
  el.video.srcObject = null;
  el.video.src = fileURL;
  await waitForMetadata();
  el.video.currentTime = 0;
  await el.video.play();
}

/** Turn technical errors into messages a person can act on. */
function friendlyError(err) {
  switch (err.name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return 'Camera permission was denied. Click the camera/lock icon in the address bar, allow camera access, then press Start again.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No camera was found. Connect a webcam and try again, or use the Video file option.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'The camera is already in use by another app or browser tab. Close it and try again.';
    case 'OverconstrainedError':
      return 'This camera does not support the requested resolution.';
    case 'InsecureContextError':
      return 'Webcam access needs HTTPS or localhost. Open the project with VS Code Live Server (http://127.0.0.1:5500) instead of opening the file directly.';
    case 'NotSupportedError':
      return 'This browser does not support webcam access. Try the latest Chrome, Edge, Firefox or Safari.';
    default:
      break;
  }
  if (err.message === 'NO_FILE') return 'Choose a video file first.';
  if (err.message === 'VIDEO_LOAD_FAILED') return 'This video could not be played. Try an MP4 (H.264) or WebM file.';
  if (err.message === 'VIDEO_TIMEOUT') return 'The video took too long to load.';
  return 'Could not start the video: ' + (err.message || err.name);
}

/** Release the webcam and stop the video element. */
function releaseSource() {
  if (stream) {
    stream.getTracks().forEach((track) => track.stop()); // turns the camera light off
    stream = null;
  }
  el.video.pause();
  if (el.video.srcObject) el.video.srcObject = null;
  if (sourceType === 'file' && fileURL) {
    try { el.video.currentTime = 0; } catch (e) { /* ignore */ }
  }
}

function setSource(type) {
  sourceType = type;
  el.tabWebcam.classList.toggle('active', type === 'webcam');
  el.tabFile.classList.toggle('active', type === 'file');
  el.fileLabel.hidden = type !== 'file';
  el.fileName.hidden = type !== 'file';
  hideBanner();
  clearOverlay();
  if (type === 'file' && fileURL) {
    el.video.srcObject = null;
    el.video.src = fileURL;          // show the uploaded video's first frame again
  } else if (type === 'webcam') {
    el.video.removeAttribute('src');
    el.video.load();                  // blank the preview
  }
  updateControls();
}


/* =====================================================================
   6. START / PAUSE / RESUME / STOP
   ===================================================================== */
function resetSession() {
  tracker.reset();
  fps = 0;
  lastVideoTime = -1;
  clearOverlay();
  updateDashboard([]);
  el.statFps.textContent = '0';
}

async function start() {
  if (state !== 'idle' || !modelReady) return;
  hideBanner();
  const token = ++runToken;
  setState('starting');
  try {
    if (sourceType === 'webcam') await startWebcam();
    else await startFile();
  } catch (err) {
    if (token === runToken) {
      releaseSource();
      setState('idle');
      showBanner(friendlyError(err), 'error');
    }
    return;
  }
  sizeStage();
  resetSession();
  setState('running');
  lastFrameTime = performance.now();
  rafId = requestAnimationFrame(loop); // begin the processing loop
}

function pause() {
  if (state !== 'running') return;
  cancelAnimationFrame(rafId);
  rafId = 0;
  el.video.pause();
  setState('paused');
}

async function resume() {
  if (state !== 'paused') return;
  try {
    await el.video.play();
  } catch (err) {
    showBanner(friendlyError(err), 'error');
    return;
  }
  setState('running');
  lastFrameTime = performance.now();
  lastVideoTime = -1;
  rafId = requestAnimationFrame(loop);
}

/** Stop everything and free resources (animation loop, camera, overlay). */
function stopAll() {
  runToken += 1;                 // any detection still in flight will be ignored
  cancelAnimationFrame(rafId);
  rafId = 0;
  releaseSource();
  clearOverlay();
  updateLiveList([]);
  el.statCurrent.textContent = '0';
  el.statFps.textContent = '0';
  setState('idle');
}


/* =====================================================================
   7. MAIN LOOP: detect -> track -> draw
   ===================================================================== */
function loop() {
  if (state !== 'running') return;
  rafId = requestAnimationFrame(loop);          // schedule the next tick first
  if (busy) return;                             // previous detection still running
  if (el.video.readyState < 2) return;          // no frame available yet
  if (sourceType === 'file' && el.video.currentTime === lastVideoTime) return; // same frame as before
  lastVideoTime = el.video.currentTime;
  detectFrame();
}

async function detectFrame() {
  busy = true;
  const token = runToken;
  try {
    const predictions = await model.detect(el.video, 20); // async, so the UI stays responsive
    if (token !== runToken || state !== 'running') return; // stopped or paused meanwhile

    const detections = predictions
      .filter((p) => p.score >= minConfidence)
      .map((p) => ({ bbox: p.bbox, class: p.class, score: p.score }));

    const visible = tracker.update(detections);
    drawTracks(visible);
    updateDashboard(visible);
    updateFps();
  } catch (err) {
    if (token === runToken) {
      stopAll();
      showBanner('Detection stopped because of an error: ' + (err.message || err), 'error');
    }
  } finally {
    busy = false;
  }
}

function updateFps() {
  const now = performance.now();
  const instant = 1000 / Math.max(1, now - lastFrameTime);
  lastFrameTime = now;
  fps = fps === 0 ? instant : fps * 0.85 + instant * 0.15; // smoothed
  el.statFps.textContent = fps.toFixed(1);
}


/* =====================================================================
   8. DRAWING BOUNDING BOXES
   ===================================================================== */
function drawTracks(tracks) {
  ctx.clearRect(0, 0, el.canvas.width, el.canvas.height);
  const lineWidth = Math.max(2, Math.round(el.canvas.width / 320));
  const fontSize = Math.max(12, Math.round(el.canvas.width / 50));
  const pad = Math.round(fontSize * 0.4);
  ctx.lineWidth = lineWidth;
  ctx.font = `600 ${fontSize}px "Segoe UI", system-ui, sans-serif`;
  ctx.textBaseline = 'middle';

  for (const t of tracks) {
    const [x, y, w, h] = t.bbox;
    ctx.strokeStyle = t.color;
    ctx.strokeRect(x, y, w, h);

    // Label: "#ID class percent"
    const label = `#${t.id} ${t.class} ${Math.round(t.score * 100)}%`;
    const labelW = ctx.measureText(label).width + pad * 2;
    const labelH = fontSize + pad * 1.2;
    const lx = Math.min(Math.max(0, x), Math.max(0, el.canvas.width - labelW));
    const ly = y - labelH >= 0 ? y - labelH : y; // flip inside the box at the top edge
    ctx.fillStyle = t.color;
    ctx.fillRect(lx, ly, labelW, labelH);
    ctx.fillStyle = '#04101f';
    ctx.fillText(label, lx + pad, ly + labelH / 2);
  }
}


/* =====================================================================
   9. DASHBOARD
   ===================================================================== */
function updateDashboard(visible) {
  el.statTotal.textContent = tracker.totalUnique();
  el.statCurrent.textContent = visible.length;

  if (visible.length) {
    const avg = visible.reduce((sum, t) => sum + t.score, 0) / visible.length;
    el.statConf.textContent = Math.round(avg * 100) + '%';
    el.confBar.style.width = Math.round(avg * 100) + '%';
  } else {
    el.statConf.textContent = '–';
    el.confBar.style.width = '0%';
  }
  updateClassChips(visible);
  updateLiveList(visible);
}

function updateClassChips(visible) {
  const counts = {};
  visible.forEach((t) => { counts[t.class] = (counts[t.class] || 0) + 1; });
  el.classChips.textContent = '';
  const names = Object.keys(counts).sort();
  if (!names.length) {
    const empty = document.createElement('span');
    empty.className = 'empty';
    empty.textContent = 'Nothing detected yet';
    el.classChips.appendChild(empty);
    return;
  }
  names.forEach((name) => {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = `${name} × ${counts[name]}`;
    el.classChips.appendChild(chip);
  });
}

function updateLiveList(visible) {
  el.trackList.textContent = '';
  if (!visible.length) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = 'No objects in view';
    el.trackList.appendChild(li);
    return;
  }
  [...visible].sort((a, b) => a.id - b.id).forEach((t) => {
    const li = document.createElement('li');
    li.className = 'track-row';

    const swatch = document.createElement('span');
    swatch.className = 'swatch';
    swatch.style.background = t.color;

    const id = document.createElement('span');
    id.className = 'track-id';
    id.textContent = '#' + t.id;

    const name = document.createElement('span');
    name.className = 'track-class';
    name.textContent = t.class;

    const pct = document.createElement('span');
    pct.className = 'track-pct';
    pct.textContent = Math.round(t.score * 100) + '%';

    li.append(swatch, id, name, pct);
    el.trackList.appendChild(li);
  });
}


/* =====================================================================
   10. EVENT LISTENERS
   ===================================================================== */
el.startBtn.addEventListener('click', start);
el.pauseBtn.addEventListener('click', pause);
el.resumeBtn.addEventListener('click', resume);
el.stopBtn.addEventListener('click', stopAll);

el.tabWebcam.addEventListener('click', () => { if (state === 'idle') setSource('webcam'); });
el.tabFile.addEventListener('click', () => { if (state === 'idle') setSource('file'); });

// Uploading a video: create a temporary URL and show it in the <video> element.
el.fileInput.addEventListener('change', () => {
  const file = el.fileInput.files[0];
  if (!file) return;
  if (!file.type.startsWith('video/')) {
    showBanner('Please choose a video file (MP4, WebM or similar).', 'error');
    return;
  }
  if (fileURL) URL.revokeObjectURL(fileURL); // free the previous file
  fileURL = URL.createObjectURL(file);
  fileReady = false;
  el.fileName.textContent = file.name;
  hideBanner();

  el.video.srcObject = null;
  el.video.src = fileURL;
  waitForMetadata()
    .then(() => {
      fileReady = true;
      sizeStage();
      showBanner('Video loaded. Press Start to detect and track objects.', 'success');
      updateControls();
    })
    .catch((err) => {
      fileReady = false;
      showBanner(friendlyError(err), 'error');
      updateControls();
    });
  updateControls();
});

// When an uploaded video reaches its end, stop cleanly.
el.video.addEventListener('ended', () => {
  if (state === 'running') {
    stopAll();
    showBanner('The video has finished. Press Start to run it again.', 'success');
  }
});

// Keep the canvas aligned if the video size changes or the window is resized.
el.video.addEventListener('resize', sizeStage);
window.addEventListener('resize', sizeStage);

el.minConf.addEventListener('input', () => {
  minConfidence = Number(el.minConf.value) / 100;
  el.minConfValue.textContent = el.minConf.value + '%';
});

el.retryBtn.addEventListener('click', () => {
  if (typeof tf === 'undefined' || typeof cocoSsd === 'undefined') location.reload();
  else loadModel();
});

// Release the camera and the temporary file URL when the page is closed.
window.addEventListener('beforeunload', () => {
  releaseSource();
  if (fileURL) URL.revokeObjectURL(fileURL);
});


/* =====================================================================
   11. START UP
   ===================================================================== */
setSource('webcam');
sizeStage();
loadModel();
